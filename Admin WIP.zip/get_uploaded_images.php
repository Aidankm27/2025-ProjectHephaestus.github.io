<?php
// Directory where images are uploaded
$uploadDirectory = 'uploads/';

// Get all image files in the directory
$images = array_filter(scandir($uploadDirectory), function($file) use ($uploadDirectory) {
    return in_array(pathinfo($file, PATHINFO_EXTENSION), ['jpg', 'jpeg', 'png', 'gif']) && is_file($uploadDirectory . $file);
});

// Return the list of image files in JSON format
echo json_encode(['images' => array_values($images)]);
?>
